"""OSMnx package version."""

__version__ = "0.16.2"
